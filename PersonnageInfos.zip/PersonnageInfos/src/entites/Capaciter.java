package entites;

public class Capaciter {
	
	
	private int capacite;
	private int nombreVie;
	private int scrore;
	private boolean etat;
	

	public int getCapacite() {
		return capacite;
	}

	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}

	public int getNombreVie() {
		return nombreVie;
	}

	public void setNombreVie(int nombreVie) {
		this.nombreVie = nombreVie;
	}

	public int getScrore() {
		return scrore;
	}

	public void setScrore(int scrore) {
		this.scrore = scrore;
	}

	public boolean isEtat() {
		return etat;
	}

	public void setEtat(boolean etat) {
		this.etat = etat;
	}

}
