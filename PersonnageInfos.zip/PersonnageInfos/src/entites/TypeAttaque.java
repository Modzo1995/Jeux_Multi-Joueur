package entites;

public class TypeAttaque {
	private int typeAttaque;
	private String description;
	
	public int getTypeAttaque() {
		return typeAttaque;
	}
	public void setTypeAttaque(int typeAttaque) {
		this.typeAttaque = typeAttaque;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
